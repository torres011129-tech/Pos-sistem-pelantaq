# POS Pelantaq - App Sunmi V3

App ini membungkus POS dalam WebView dan menghantar resit terus ke printer dalaman Sunmi
(tiada RawBT). Selepas bayar, resit dicetak automatik. Butang "Cetak Sunmi" untuk cetak semula.

## Sebelum bina
1. Buka app/src/main/assets/index.html
2. Tampal tetapan Firebase di blok `FB` (kalau mahu sync). Kosongkan kalau tidak.

## Cara bina tanpa Android Studio (GitHub)
1. Buat repo GitHub baru, upload SEMUA fail dalam folder ini (termasuk folder .github).
2. Tab Actions > "Build APK" > Run workflow.
3. Bila siap, buka run tersebut > Artifacts > muat turun pelantaq-pos-apk (fail zip berisi app-debug.apk).
4. Pindah app-debug.apk ke Sunmi V3 dan pasang (benarkan "install from unknown sources").

## Cara bina dengan Android Studio
Open folder ini > tunggu Gradle sync > Build > Build APK(s).

## Nota
- Belum diuji pada Sunmi V3 sebenar. Kalau cetak tak keluar, semak printer Sunmi berfungsi
  dengan app lain dan beritahu mesej ralat.
- Lebar resit 32 aksara (kertas 58mm).
