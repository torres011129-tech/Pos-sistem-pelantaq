package com.pelantaq.pos

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.sunmi.peripheral.printer.InnerPrinterCallback
import com.sunmi.peripheral.printer.InnerPrinterManager
import com.sunmi.peripheral.printer.SunmiPrinterService

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var printer: SunmiPrinterService? = null

    private val callback = object : InnerPrinterCallback() {
        override fun onConnected(service: SunmiPrinterService) { printer = service }
        override fun onDisconnected() { printer = null }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "SunmiBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val external = u.scheme == "whatsapp" || u.host == "wa.me" || u.scheme == "rawbt"
                if (external) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        try { InnerPrinterManager.getInstance().bindService(this, callback) } catch (_: Exception) {}
    }

    inner class Bridge {
        // Dipanggil dari POS: SunmiBridge.print(base64 ESC/POS)
        @JavascriptInterface
        fun print(base64: String): Boolean {
            val p = printer ?: return false
            return try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                p.printerInit(null)
                p.sendRAWData(bytes, null)
                true
            } catch (_: Exception) { false }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try { InnerPrinterManager.getInstance().unBindService(this, callback) } catch (_: Exception) {}
        super.onDestroy()
    }
}
